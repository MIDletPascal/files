<?php
  $id=$_GET['id'];
  
  mysql_connect("127.0.0.1", "root", "1qaz2wsx");
  mysql_select_db("my");
 
  $norm=$date-60;
  $res=mysql_query("SELECT * FROM `my`.`tictactoe` WHERE `id`='$id'");
  while ($row=mysql_fetch_assoc($res)) {
    echo $row['table'].' ';
  }
?>
