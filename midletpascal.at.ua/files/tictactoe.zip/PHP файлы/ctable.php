<?php
  $name=$_GET['name'];
  $date=time();
  
  mysql_connect("127.0.0.1", "root", "1qaz2wsx");
  mysql_select_db("my");
  
  mysql_query("INSERT INTO `my`.`tictactoe` (`name1`, `name2`, `table`, `date`) VALUES ('$name', '', '0000000001', '$date')");
 
  $res=mysql_result(mysql_query("SELECT * FROM `my`.`tictactoe` WHERE `name1`='$name' AND `date`='$date'"), 0);
 
  echo $res;

?>
