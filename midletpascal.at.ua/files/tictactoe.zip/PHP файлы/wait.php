<?php
  $id=$_GET['id'];

  mysql_connect("127.0.0.1", "root", "1qaz2wsx");
  mysql_select_db("my");
 
  $res=mysql_query("SELECT * FROM `my`.`tictactoe` WHERE `id`=$id");
  while ($row=mysql_fetch_assoc($res)) {
    if ($row['name2']=='') {
      echo 'NOT';
    } else {
      echo $row['name2'];
    }
  }
?>
