<?php
  $id=$_GET['id'];
  $table=$_GET['table'];
  $date=time();
  
  mysql_connect("127.0.0.1", "root", "1qaz2wsx");
  mysql_select_db("my");
  
  mysql_query("UPDATE `my`.`tictactoe` SET `table`='$table' WHERE `id`='$id'");

  echo 'OK';

?>
