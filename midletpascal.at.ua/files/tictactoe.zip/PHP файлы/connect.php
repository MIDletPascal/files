<?php
  $name=$_GET['name'];
  $id=$_GET['id'];
  $date=time();
  
  mysql_connect("127.0.0.1", "root", "1qaz2wsx");
  mysql_select_db("my");
  
  mysql_query("UPDATE `my`.`tictactoe` SET `name2`='$name' WHERE `id`='$id'");
  $res=mysql_query("SELECT * FROM `my`.`tictactoe` WHERE `id`=$id");
  while ($row=mysql_fetch_assoc($res)) {
    echo $row['name1'];
  }


?>
