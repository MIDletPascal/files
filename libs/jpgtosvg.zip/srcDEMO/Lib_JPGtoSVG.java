
import com.siemens.mp.io.file.FileConnection;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.microedition.io.Connector;
import javax.microedition.io.InputConnection;
import javax.microedition.lcdui.Image;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author �����
 */
public class Lib_JPGtoSVG {

    public static Image svgg;
    private static char map1[];
    private static byte map2[];
    private static byte[] abyte0;
    private static byte[] abyte2;
    private static String base64JPG;
    public static int wJPG;
    public static int hJPG;
    public static Image JPG;
    public static String SVG = "";

    public Lib_JPGtoSVG() {
    }

    public static void stringSVG() {
        SVG = SVG + "<?xml version=" + '"' + "1.0" + '"' + " encoding=" + '"' + "UTF-8" + '"' + "?>";
        SVG = SVG + "<!DOCTYPE svg PUBLIC " + '"' + "-//W3C//DTD SVG 1.1 Tiny//EN" + '"' + "\n" + '"' + "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11-tiny.dtd" + '"' + ">";
        SVG = SVG + "<svg width=" + '"' + wJPG + '"' + " height=" + '"' + hJPG + '"' + " viewBox=" + '"' + "0 0 " + wJPG + " " + hJPG + '"' + " id=" + '"' + "svg" + '"' + " display=" + '"' + "inline" + '"' + " version=" + '"' + "1.1" + '"' + " baseProfile=" + '"' + "tiny" + '"' + ">";
        SVG = SVG + "<image  x=" + '"' + "0" + '"' + " y=" + '"' + "0" + '"' + " width=" + '"' + wJPG + '"' + " height=" + '"' + hJPG + '"' + " id=" + '"' + "XMLID_1_" + '"' + " xlink:href=" + '"' + "data:image/jpeg;base64," + base64JPG + '"' + ">\n</image>\n</svg>";

    }

    public static void saveSVG(String path, String text) {
        try {
            FileConnection fs = (FileConnection) Connector.open("file:///" + path);
            if (!fs.exists()) {
                fs.create();
            }
            DataOutputStream os = fs.openDataOutputStream();
            byte d[] = new byte[text.length()];
            for (int i = 0; i < d.length; i++) {
                char b = text.charAt(i);
                if (b > '\377') {
                    d[i] = (byte) (b - 848);
                } else {
                    d[i] = (byte) b;
                }
            }

            os.write(d, 0, d.length);
            os.flush();
            os.close();
        } catch (Exception e) {
        }
    }

    public static String encodestring(byte[] s) {
        return new String(encode(s));
    }

    private static char[] encode(byte in[]) {
        return encode(in, in.length);
    }

    private static char[] encode(byte in[], int iLen) {
        int oDataLen = (iLen * 4 + 2) / 3;
        int oLen = ((iLen + 2) / 3) * 4;
        char out[] = new char[oLen];
        int ip = 0;
        for (int op = 0; ip < iLen; op++) {
            int i0 = in[ip++] & 0xff;
            int i1 = ip >= iLen ? 0 : in[ip++] & 0xff;
            int i2 = ip >= iLen ? 0 : in[ip++] & 0xff;
            int o0 = i0 >>> 2;
            int o1 = (i0 & 3) << 4 | i1 >>> 4;
            int o2 = (i1 & 0xf) << 2 | i2 >>> 6;
            int o3 = i2 & 0x3f;
            out[op++] = map1[o0];
            out[op++] = map1[o1];
            out[op] = op >= oDataLen ? '=' : map1[o2];
            op++;
            out[op] = op >= oDataLen ? '=' : map1[o3];
        }

        return out;
    }


    static {
        map1 = new char[64];
        int i = 0;
        for (char c = 'A'; c <= 'Z'; c++) {
            map1[i++] = c;
        }

        for (char c = 'a'; c <= 'z'; c++) {
            map1[i++] = c;
        }

        for (char c = '0'; c <= '9'; c++) {
            map1[i++] = c;
        }

        map1[i++] = '+';
        map1[i++] = '/';
        map2 = new byte[128];
        for (i = 0; i < map2.length; i++) {
            map2[i] = -1;
        }

        for (i = 0; i < 64; i++) {
            map2[map1[i]] = (byte) i;
        }

    }

    public static byte[] readJPG(String path) {

        try {
            int i;
            FileConnection fc = (FileConnection) Connector.open("file:///" + path, Connector.READ);
            i = (int) fc.fileSize();
            abyte0 = new byte[i];
            DataInputStream dis = fc.openDataInputStream();
            dis.read(abyte0, 0, i);
            dis.close();
            fc.close();
        } catch (IOException ex) {
        }
        return abyte0;
    }

    public static void saveJPGtoSVG(String path, String path2) throws IOException {

        byte[] abyte2 = readJPG(path);
        base64JPG = encodestring(abyte2);
        InputConnection ic = (InputConnection) Connector.open("file:///" + path);
        InputStream is = ic.openInputStream();
        JPG = Image.createImage(is);
        ic.close();
        is.close();
        wJPG = JPG.getWidth();
        hJPG = JPG.getHeight();
        stringSVG();
        saveSVG(path2, SVG);
    }
}
