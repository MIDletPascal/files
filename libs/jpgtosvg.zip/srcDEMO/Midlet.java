/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.TextField;
import javax.microedition.midlet.*;

/**
 * @author �����
 */
public class Midlet extends MIDlet implements CommandListener{
   public static Display ds;
    public static Form f = new Form("test");
    public static TextField tf = new TextField("���", "0:/.jpg", 512, TextField.ANY);
    public static TextField tf2 = new TextField("����", "0:/.svg", 512, TextField.ANY);

    public Midlet() {
        ds = Display.getDisplay(this);
        f.append(tf);
        f.append(tf2);
        f.addCommand(new Command("OK", 1, 1));
        f.setCommandListener(this);
    }

    public void startApp() {
        ds.setCurrent(f);
    }

    public void pauseApp() {
    }

    public void destroyApp(boolean unconditional) {
        notifyDestroyed();
    }

    public void commandAction(Command c, Displayable d) {
        int z = c.getPriority();
        if (z == 1) {
            try {
                Lib_JPGtoSVG.saveJPGtoSVG(tf.getString(), tf2.getString());
                destroyApp(true);
            } catch (IOException ex) {
                destroyApp(true);
            }
        }
    }
}
