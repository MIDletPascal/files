import java.io.*;
import javax.microedition.io.Connector;
import javax.microedition.io.HttpConnection;

class Lib_web {
    public static int open(String s)
    {
      try{  
		o = null;
      	i = null;
		c = (HttpConnection)Connector.open(s);
        return -1;
	}catch(Exception exception) {c = null; return 0;}
    }

    public int opened()
    {
        return c == null ? 0 : -1;
    }

    public static void close()
    {
        try
        {
            if(i != null)
            {
                i.close();
                i = null;
            }
            if(o != null)
            {
                o.close();
                o = null;
            }
            c.close();
            c = null;
        }
        catch(Exception exception) {c = null; }
    }

    public static void set_property(String s, String s1)
    {
        try{
            c.setRequestProperty(s, s1);
        }
        catch(Exception exception) { }
    }

    public static void set_method(String s)
    {
        try
        {
            c.setRequestMethod(s);
        }
        catch(Exception exception) {}
    }

    public static String get_header(String s)
    {
	try{
        String s1;
        s1 = c.getHeaderField(s);
        if(s1 == null)
            s1 = "";
        return s1;
	}catch(Exception exception) {return "";}
    }

    public static String get_name(int s)
    {
	try{
        String s1;
        s1 = c.getHeaderFieldKey(s);
        if(s1 == null)
            s1 = "";
        return s1;
	}catch(Exception exception) {return "";}
    }

    public static int set_body(String s)
    {
	try{
	    if(o==null)
	    	o = c.openOutputStream();
        o.write(s.getBytes());
                o.flush();
        return -1;
	}catch( Exception exception) {
        o = null;
        return 0;
	}
    }

    public static int send()
    {
	try{
        int k;
        k = c.getResponseCode();
        i = c.openInputStream();
        return k;
        }catch( Exception exception) {return -1;}
    }

    public static String get_response()
    {
	try{
        StringBuffer stringbuffer;
        stringbuffer = new StringBuffer();
        int k;
        while((k = i.read()) != -1) 
            stringbuffer.append((char)k);
        return stringbuffer.toString();
        }catch( Exception exception)  {return exception.toString();}
    }

	public static InputStream get_stream() throws IOException{
		return i;
	}
		
    public static HttpConnection c;
    public static OutputStream o;
    public static InputStream i;
}
