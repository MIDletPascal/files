import javax.microedition.lcdui.*;
import javax.microedition.midlet.MIDlet;

public class FW extends MIDlet
    implements CommandListener
{

    public boolean threadStarted;
    public M m;
    public static FW fw = null;
    public static int MP;
    public Display display;
    public static Command LC;
    public static Displayable CD;
    public static Form F;
    public static TextBox TB;
    public static Alert A;
    public static List L;

    public FW()
    {
        threadStarted = false;
        m = null;
    }

    public void startApp()
    {
        MP = 0;
        display = Display.getDisplay(((MIDlet) (this)));
        fw = this;
        LC = null;
        if(m == null)
        {
            m = new M();
            M.T = m;
            M.I = Image.createImage(m.getWidth(), m.getHeight());
            M.G = M.I.getGraphics();
            M.KC = 0;
            TB = new TextBox("", "", 2, 0);
            A = new Alert("", "", ((Image) (null)), AlertType.INFO);
            L = new List("", 3);
            display.setCurrent(((Displayable) (m)));
            CD = ((Displayable) (m));
            try
            {
                m.setCommandListener(((CommandListener) (this)));
            }
            catch(Exception exception) { }
            F = new Form("");
            F.setCommandListener(((CommandListener) (this)));
        } else
        {
            m.repaint();
            m.serviceRepaints();
        }
        if(!threadStarted)
        {
            (new Thread(((Runnable) (m)))).start();
            threadStarted = true;
        }
    }

    public void pauseApp()
    {
        MP = -1;
    }

    public void destroyApp(boolean flag)
    {
        m = null;
        M.I = null;
        M.G = null;
        CD = null;
        F = null;
        TB = null;
        A = null;
        L = null;
        fw = null;
        LC = null;
        notifyDestroyed();
    }

    public void commandAction(Command command, Displayable displayable)
    {
        LC = command;
    }

    public void threadaction(){
}

}
