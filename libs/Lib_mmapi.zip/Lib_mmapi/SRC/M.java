import java.util.Random;
import javax.microedition.lcdui.*;

public class M extends Canvas
    implements Runnable
{

    public static Random RNG;
    public static Image I;
    public static M T;
    public static Graphics G;
    public static int KC;
    public static int KP;
    public static int IC[];

    public M()
    {
    }

    public void paint(Graphics g)
    {
        g.drawImage(I, 0, 0, 20);
    }

    public void run()
    {
        try
        {
            R();
        }
        catch(Exception _ex) { }
    }

    public void keyPressed(int i)
    {
        KP = KC = i;
    }

    public void keyReleased(int i)
    {
        KP = 0;
    }

    public static void R()
        throws Exception
    {
        RNG = new Random();
        IC = new int[25];
        KC = 0;
        KP = 0;
        FW.fw.destroyApp(true);
    }

    public static void threadaction(){}
}
