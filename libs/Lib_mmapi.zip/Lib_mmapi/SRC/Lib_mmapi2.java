import com.motorola.io.*;
import javax.microedition.io.*;
import javax.microedition.media.*;
import javax.microedition.media.control.*;
import java.io.*;
import javax.microedition.lcdui.*;



public class Lib_mmapi2 {

  //private static Player p;
  private static VolumeControl vc;
  private static VideoControl vid;
  private static String err = new String();

Lib_mmapi2(){};

  public static String amrfile(){return "audio/amr";}
  public static String midifile(){return "audio/midi";}
  public static String wavefile(){return "audio/x-wav";}
  public static String mp3file(){return "audio/mpeg";}

  public static void init(int volume){

      vc=(VolumeControl)P.p.getControl("VolumeControl");
      vc.setLevel(volume);
  }

  public static void loadvideo(String file, int volume)
            {
        try
                {
           P.p = Manager.createPlayer(file);
            P.p.realize();
            vid = (VideoControl)((Controllable) (P.p)).getControl("VideoControl");
            if(vid != null)
                    {
                FW.F.append((Item)vid.initDisplayMode(0, ((Object) (null))));
                vid.setDisplayFullScreen(true);
                Display.getDisplay(((javax.microedition.midlet.MIDlet) (FW.fw))).setCurrent(((Displayable) (FW.F)));
                    }
                    vc=(VolumeControl)P.p.getControl("VolumeControl");
                    vc.setLevel(volume);
                }
        catch(Exception ex)
                {
            err = ((Throwable) (ex)).getMessage();
                }
            }


   public static int loadaudio(String FileName, String MediaType, int volume ) {
    try {
      FileConnection conn = (FileConnection)Connector.open("file://"+
          FileName);
      InputStream is = conn.openInputStream();
      P.p = Manager.createPlayer(is, MediaType);
      P.p.realize();
      vc=(VolumeControl)P.p.getControl("VolumeControl");
      vc.setLevel(volume);

       return 1;
    }
    catch (Exception ex) {
      return 0;
    }
  }


  public static int play() {
    try {
    P.p.start();
    return 1;
    }
    catch (Exception ex) {
    return 0;
    }
  }

  public static int pause() {
  try{
    P.p.stop();
    return 1;
  }
  catch (Exception ex){
    return 0;
  }
}


  public static void destroy(){
    P.p.close();
  }

  public static int setposition(int position){
    long pos;
    pos=(long)position;
    try{
   P.p.setMediaTime(pos);
   return 1;
    }
    catch (Exception ex){return 0;}
  }

  public static int getposition(){
    int pos;
    pos=(int)P.p.getMediaTime();
    return pos;
  }

  public static int getduration(){
    int len;
    len=(int)P.p.getDuration();
    return len;
  }

  public static void setloopcount(int count){
  P.p.setLoopCount(count);
  }

  public static void setvolume(int volume){
    vc.setLevel(volume);
  }

  public static void mute(){vc.setMute(true);}
  public static void unmute(){vc.setMute(false);}


}
