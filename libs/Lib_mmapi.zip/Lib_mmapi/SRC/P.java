import javax.microedition.media.Player;
public class P
{

  public static Player p = null;
}
