public class Lib_dbl {
	public static void init(int sz) {
		v = new double[sz];
	}
	
	public static String get(int idx) {
		return (new Double(v[idx])).toString();
	}
	
	public static int getint(int idx) {
		return (new Double(v[idx])).intValue();
	}
	
	public static void copy(int idx1, int idx2) {
		v[idx1] = v[idx2];
	}

	public static void todegrees(int idx) {
		v[idx] = Math.toDegrees(v[idx]);
	}

	public static void toradians(int idx) {
		v[idx] = Math.toRadians(v[idx]);
	}

	public static void sin(int idx) {
		v[idx] = Math.sin(v[idx]);
	}

	public static void cos(int idx) {
		v[idx] = Math.cos(v[idx]);
	}

	public static void tan(int idx) {
		v[idx] = Math.tan(v[idx]);
	}

	public static void sqrt(int idx) {
		v[idx] = Math.sqrt(v[idx]);
	}

	public static void plus(int idx1, int idx2) {
		v[idx1] = v[idx1]+v[idx2];
	}

	public static void sub(int idx1, int idx2) {
		v[idx1] = v[idx1]-v[idx2];
	}

	public static void mul(int idx1, int idx2) {
		v[idx1] = v[idx1]*v[idx2];
	}

	public static void div(int idx1, int idx2) {
		v[idx1] = v[idx1]/v[idx2];
	}

	public static void set(int idx, String vl) {
		v[idx] = Double.valueOf(vl).doubleValue();
	}
	
	private static double v[];
}