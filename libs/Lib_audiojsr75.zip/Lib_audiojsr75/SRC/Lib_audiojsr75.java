import javax.microedition.media.*;
import javax.microedition.media.control.*;
import java.io.*;
import javax.microedition.io.*;
import javax.microedition.io.file.*;

public class Lib_audiojsr75 {

  private static Player p;
  private static VolumeControl vc;


  public static String amrfile(){return "audio/amr";}
  public static String midifile(){return "audio/midi";}
  public static String wavefile(){return "audio/x-wav";}
  public static String mp3file(){return "audio/mpeg";}

   public static int loadfile(String FileName, String MediaType, int volume ) {
    try {
      FileConnection conn = (FileConnection)Connector.open("file://"+
          FileName);
      InputStream is = conn.openInputStream();
      p = Manager.createPlayer(is, MediaType);
      p.realize();
      vc=(VolumeControl)p.getControl("VolumeControl");
      vc.setLevel(volume);

       return 1;
    }
    catch (Exception ex) {
      return 0;
    }
  }


  public static int play() {
    try {
    p.start();
    return 1;
    }
    catch (Exception ex) {
    return 0;
    }
  }

  public static int pause() {
  try{
    p.stop();
    return 1;
  }
  catch (Exception ex){
    return 0;
  }
}


  public static void destroy(){
    p.close();
  }

  public static int setposition(int position){
    long pos;
    pos=(long)position;
    try{
   p.setMediaTime(pos);
   return 1;
    }
    catch (Exception ex){return 0;}
  }

  public static int getposition(){
    int pos;
    pos=(int)p.getMediaTime();
    return pos;
  }

  public static int getduration(){
    int len;
    len=(int)p.getDuration();
    return len;
  }

  public static void setloopcount(int count){
  p.setLoopCount(count);
  }

  public static void setvolume(int volume){
    vc.setLevel(volume);
  }

  public static void mute(){vc.setMute(true);}
  public static void unmute(){vc.setMute(false);}


}
