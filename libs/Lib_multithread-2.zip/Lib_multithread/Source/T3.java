class T3 extends Thread {

  public void run(){
    M.p3();
  }

  public void interrupt(){

  }
}
