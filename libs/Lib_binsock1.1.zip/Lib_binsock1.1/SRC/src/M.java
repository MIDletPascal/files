public class M {
    public M() {
    }

    public static void onerror(int _int, String string, String string2, int _int3) throws Exception { }

}
