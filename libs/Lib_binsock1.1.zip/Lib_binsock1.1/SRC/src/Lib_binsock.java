import java.io.InputStream;
import java.io.OutputStream;
import javax.microedition.io.*;

public class Lib_binsock {

  private static SocketConnection con;
  private static InputStream is;
  private static OutputStream os;
  private static int tx = 0;
  private static int rx = 0;
  private static boolean debug = false;
  private static int sender = 0;

  private static final int ERR_OPENERROR = 0;
  private static final int ERR_CLOSEERROR = 1;
  private static final int ERR_AVAILERROR = 2;
  private static final int ERR_READERROR = 3;
  private static final int ERR_WRITEERROR = 4;
  private static final int ERR_FLUSHERROR = 5;


    public Lib_binsock() {}

    public static void debug_register(int idx){
        sender = idx;
    }

    private static void err(Exception ex, int code, String msg){
        if(debug) try{M.onerror(sender, ex.toString(), msg, code);}catch(Exception e){}
    }

    public static void enable_debug(int flag){
        if(flag==1){
            debug = true;
        } else
            debug = false;
    }

    public static int open(String url){
        try{
            con = (SocketConnection)Connector.open(url);
            is = con.openInputStream();
            os = con.openOutputStream();
        }catch(Exception e){
            err(e, ERR_OPENERROR, "Unable to open connection or data stream");
            return -1;}
        return 1;
    }

    public static void close(){
        try{
            if(is != null){
                is.close();
                is = null;
            }
            if(os != null){
                os.flush();
                os.close();
                os = null;
            }
            con.close();
            con = null;
        }
        catch(Exception e)
        {
            err(e, ERR_CLOSEERROR, "Error closing connection or data stream, connection set to 'null'");
            con = null;
        }
    }

    public static int available(){
        if(is != null){
            try{
                return is.available();
            }catch(Exception e){
                err(e, ERR_AVAILERROR, "");
                return -1;}
        }
        else{
            return 0;
        }
    }

    public static int read_byte(){
        rx++;
        try{
            return is.read();
        }catch(Exception e){
            err(e, ERR_READERROR, "Error reading byte from stream");
            return -1;
        }
    }

    public static int rx_count(){
        return rx;
    }

    public static int tx_count(){
        return tx;
    }

    public static InputStream get_in_stream(){
        return is;
    }

    public static int write_byte(int data){
        tx++;
        try{
            os.write(data);
            return 1;
           }catch(Exception e){
               err(e, ERR_WRITEERROR, "Error writing byte to stream");
               return -1;
           }
    }

    public static int write_bin(String data){
        byte d[] = data.getBytes();
        tx = tx+d.length;
        try{
            os.write(d);
        }catch(Exception e){
            err(e, ERR_WRITEERROR, "Error writing binary to stream");
            return -1;}
        return 1;
    }

    public static String read_bin(int len){
        byte d[] = new byte[len] ;
        int dl = 0;
        try{
           dl = is.read(d);
        }catch(Exception e){
            err(e, ERR_READERROR, "Error reading binary from stream");
            return null;}

        if(dl != 0){
            return new String(d);
        }
        else{
            return null;}
        }
    
    public static int flush(){
    		try{
    		   os.flush();
    		}catch(Exception e){
    			  err(e, ERR_FLUSHERROR, "Error in [os.flush()] call");
    			  return -1;}
    			  
    	  return 1;
    	
    }

    }


