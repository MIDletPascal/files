import javax.microedition.lcdui.*;

public class Lib_text{
	public static void init() {
            MLT = new MultiLineText();
	}

	public static void set_text_par(int x, int y, int w, int h, int dy, int fsz, int fst, int ft, String s) {
            MLT.SetTextPar(x, y, w, h, dy, fsz, fst, ft, M.G, s);
	}

	public static void draw_mult_str() {
            MLT.DrawMultStr();
	}
        
        public static void mode_down() {
            MLT.MoveDown();
        }

        public static void mode_up() {
            MLT.MoveUp();
        }

        public static void page_down() {
            MLT.PageDown();
        }

        public static void page_up() {
            MLT.PageUp();
        }

	private static MultiLineText MLT;
}