class Lib_keys{
	
	public static int get_key_states(){
		return M.T.getKeyStates();
	}

}