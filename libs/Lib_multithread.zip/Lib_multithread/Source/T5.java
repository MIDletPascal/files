class T5 extends Thread {

  public void run(){
    M.p5();
  }

  public void interrupt(){

  }
}
