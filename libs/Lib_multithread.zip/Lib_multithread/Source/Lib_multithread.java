class Lib_multithread {

  public static T1 t1;
  public static T2 t2;
  public static T3 t3;
  public static T4 t4;
  public static T5 t5;

  public static void setpriority(int idx,int priority){
  if(idx==1){t1.setPriority(priority);}
  if(idx==2){t2.setPriority(priority);}
  if(idx==3){t3.setPriority(priority);}
  if(idx==4){t4.setPriority(priority);}
  if(idx==5){t5.setPriority(priority);}
}


  public static int max_priority(){
  return Thread.MAX_PRIORITY;
}

public static int min_priority(){
  return Thread.MIN_PRIORITY;
}

public static int norm_priority(){
  return Thread.NORM_PRIORITY;
}

  public static void init(int idx){
  if(idx==1){t1=new T1();
    setpriority(1,norm_priority());
  }
  if(idx==2){t2=new T2();
  setpriority(2,norm_priority());
}
if(idx==3){t3=new T3();
  setpriority(3,norm_priority());
  }
  if(idx==4){t4=new T4();
  setpriority(4,norm_priority());
  }
  if(idx==5){t5=new T5();
  setpriority(5,norm_priority());
}

  }

  public static void start(int idx){
    if(idx==1){t1.start();}
    if(idx==2){t2.start();}
    if(idx==3){t3.start();}
    if(idx==4){t4.start();}
    if(idx==5){t5.start();}
  }

  public static void stop(int idx){
    if(idx==1){t1.interrupt();}
    if(idx==2){t2.interrupt();}
    if(idx==3){t3.interrupt();}
    if(idx==4){t4.interrupt();}
    if(idx==5){t5.interrupt();}
  }

  public static void add(int idx){
    if (idx==1){
     try{
      t1.join();
     }catch(Exception ex){}}

   if (idx==2){
     try{
      t2.join();
     }catch(Exception ex){}}

   if (idx==3){
     try{
      t3.join();
     }catch(Exception ex){}}

   if (idx==4){
     try{
      t4.join();
     }catch(Exception ex){}}

   if (idx==5){
     try{
      t5.join();
     }catch(Exception ex){}}
  }

}
