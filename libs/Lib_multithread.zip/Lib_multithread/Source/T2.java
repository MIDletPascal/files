class T2 extends Thread {

  public void run(){
    M.p2();
  }

  public void interrupt(){

  }
}
