class T1 extends Thread {

  public void run(){
    M.p1();
  }

  public void interrupt(){

  }
}
