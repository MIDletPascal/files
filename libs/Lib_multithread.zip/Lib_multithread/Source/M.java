public class M {

  public static void p1(){

  }

  public static void p2(){

  }

  public static void p3(){

  }

  public static void p4(){

  }

  public static void p5(){

  }



}
