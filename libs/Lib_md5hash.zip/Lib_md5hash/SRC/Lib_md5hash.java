class Lib_md5hash {
public static MD5 md5;
  public static String gethash(String inp){

  md5.Init();
  md5.Update(inp);
 return md5.asHex();
}
}
