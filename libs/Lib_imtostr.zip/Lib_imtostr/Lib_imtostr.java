import javax.microedition.lcdui.Image;
public class Lib_imtostr {
    public Lib_imtostr() {}

    public static String imagetostring(Image image){
    return image.toString();
    }
}
