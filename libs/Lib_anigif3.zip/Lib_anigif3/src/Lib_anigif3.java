import javax.microedition.lcdui.Image;
import javax.microedition.io.file.*;
import java.io.*;
import javax.microedition.io.*;

public class Lib_anigif3{

public static Image imgFrame;
public static GifFrame  gifFrame;
public static FileConnection fc;
public static DataInputStream is;
public static HttpConnection hc=null;

public static void load_gif_res(String url){
Image img;
GifImage  gif;
GifFrame  frm, last;
gif = GifImage.startScan(url);
last = null;
while((img = gif.nextImage()) != null) {
frm = new GifFrame(img, gif.getDelay() * 10);
if(last == null)
gifFrame = frm;
else
last.next = frm;
last = frm;
}
gif.closeScan();
last.next = gifFrame;
gifFrame = last;
imgFrame = null;
}

public static int load_gif_fs(String url){
Image img;
GifImage  gif;
GifFrame  frm, last;
int flag=1;
try{
    fc = (FileConnection) Connector.open(url);
    is = fc.openDataInputStream();
}catch(Exception ex){flag=0;}
gif = GifImage.startScan(is);
last = null;
while((img = gif.nextImage()) != null) {
frm = new GifFrame(img, gif.getDelay() * 10);
if(last == null)
gifFrame = frm;
else
last.next = frm;
last = frm;
}
gif.closeScan();
try{
is.close();
fc.close();
}catch(Exception ex){}
last.next = gifFrame;
gifFrame = last;
imgFrame = null;
return flag;
}

public static int load_gif_http(String url){
    Image img;
    GifImage  gif;
    GifFrame  frm, last;
    int flag=1;
        try {
        hc = (HttpConnection) Connector.open(url);
        hc.setRequestMethod(HttpConnection.GET);
        hc.setRequestProperty("User-Agent","Profile/MIDP-2.0 Configuration/CLDC-1.0");
        hc.setRequestProperty("Content-Language", "en-CA");
        is=hc.openDataInputStream();

    }catch(Exception ex){flag=0;}

    gif = GifImage.startScan(is);
    last = null;
    while((img = gif.nextImage()) != null) {
    frm = new GifFrame(img, gif.getDelay() * 10);
    if(last == null)
    gifFrame = frm;
    else
    last.next = frm;
    last = frm;
    }
    gif.closeScan();
    try{
    is.close();
    hc.close();
    }catch(Exception ex){}
    last.next = gifFrame;
    gifFrame = last;
    imgFrame = null;
    return flag;
    }


 public static Image get_frame(){
imgFrame = (gifFrame = gifFrame.next).getImage();
return imgFrame;
}

 public static int get_delay(){
     return gifFrame.getDelay();
 }

public static int get_width(){
Image img=null;
img=gifFrame.getImage();
return img.getWidth();

}
 public static int get_height(){
Image img=null;
img=gifFrame.getImage();
return img.getHeight();

}


}

