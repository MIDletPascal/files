import javax.microedition.lcdui.Image;

public class GifFrame
{
  public GifFrame next;

  private int nX, nY, nDelay;
  private Image imgFrame;

  public  GifFrame(Image img, int x, int y, int n)
  {
    imgFrame = img;
    nX = x;
    nY = y;
    nDelay = n;
    next = null;
  }

  public  GifFrame(Image img, int n)
  {
    this(img, 0, 0, n);
  }

  public Image  getImage()
  {
    return(imgFrame);
  }

  public int  getX()
  {
    return(nX);
  }

  public int  getY()
  {
    return(nY);
  }

  public int  getDelay()
  {
    return(nDelay);
  }
}

