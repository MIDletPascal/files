class P10 extends Thread
{

    public void run() 
    {
        try {
            M.p10();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void interrupt()
    {
    }
}