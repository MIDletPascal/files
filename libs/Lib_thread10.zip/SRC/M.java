import java.util.Random;
import javax.microedition.lcdui.*;

public class M extends Canvas
    implements Runnable
{

    public static Random RNG;
    public static Image I;
    public static M T;
    public static Graphics G;
    public static int KC;
    public static int KP;
    public static int IC[];
    public static int i;
    public static int action;
    public static int j;
    public static int key;

    public M()
    {
    }

    public void paint(Graphics g)
    {
        g.drawImage(I, 0, 0, 20);
    }

    public void run()
    {
        try
        {
            R();
        }
        catch(Exception _ex) { }
    }

    public void keyPressed(int k)
    {
        KP = KC = k;
    }

    public void keyReleased(int k)
    {
        KP = 0;
    }

    public static void p1()
        throws Exception
    {
    }

    public static void p2()
        throws Exception
    {
    }

    public static void p3()
        throws Exception
    {
    }

    public static void p4()
        throws Exception
    {
    }

    public static void p5()
        throws Exception
    {
    }

    public static void p6()
        throws Exception
    {
    }

    public static void p7()
        throws Exception
    {
    }

    public static void p8()
        throws Exception
    {
    }

    public static void p9()
        throws Exception
    {
    }

    public static void p10()
        throws Exception
    {
    }

    public static void R()
        throws Exception
    {
        RNG = new Random();
        IC = new int[25];
        KC = 0;
        KP = 0;
        i = 0;
        j = 0;
        key = 0;
        action = 0;
        Thread.sleep(500);
        j = i;
        G.setColor(0, 0, 0);
        G.fillRect(0, 20, 100, 40);
        G.setColor(255, 255, 255);
        
        T.repaint();
        T.serviceRepaints();
        FW.fw.destroyApp(true);
    }
}
