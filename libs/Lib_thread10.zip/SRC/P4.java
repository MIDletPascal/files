class P4 extends Thread
{

    public void run() 
    {
    
            M.p4();
     
    }

    public void interrupt()
    {
    }
}