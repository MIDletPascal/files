class P6 extends Thread
{

    public void run()
    {
        try {
            M.p6();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void interrupt()
    {
    }
}