class P3 extends Thread
{

    public void run() 
    {
     
            M.p3();
      
    }

    public void interrupt()
    {
    }
}