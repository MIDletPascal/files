class P7 extends Thread
{

    public void run() 
    {
        try {
            M.p7();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void interrupt()
    {
    }
}