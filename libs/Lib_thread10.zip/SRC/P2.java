class P2 extends Thread
{

    public void run() 
    {
        try {
       
            M.p2();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
      
    }

    public void interrupt()
    {
    }
}