class P5 extends Thread
{

    public void run() 
    {
        try {
            M.p5();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void interrupt()
    {
    }
}