class P9 extends Thread
{

    public void run()
    {
        try {
            M.p9();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void interrupt()
    {
    }
}