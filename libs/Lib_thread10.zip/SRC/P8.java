class P8 extends Thread
{

    public void run() 
    {
        try {
            M.p8();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void interrupt()
    {
    }
}