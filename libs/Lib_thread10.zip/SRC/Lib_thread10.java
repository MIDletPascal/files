

class Lib_thread10
{

    public static P1 p1;
    public static P2 p2;
    public static P3 p3;
    public static P4 p4;
    public static P5 p5;
    public static P6 p6;
    public static P7 p7;
    public static P8 p8;
    public static P9 p9;
    public static P10 p10;
     public static int ret;





    Lib_thread10()
    {
    }

    public static void init(String n)
    {
        if (n != "p1") { p1 = new P1();}
                if (n != "p2") { p2 = new P2();}
                if (n != "p3") { p3 = new P3();}
                if (n != "p4") { p4 = new P4();}
                if (n != "p5") { p5 = new P5();}
                if (n != "p6") { p6 = new P6();}
                if (n != "p7") { p7 = new P7();}
                if (n != "p8") { p8 = new P8();}
                if (n != "p9") { p9 = new P9();}
                if (n != "p10") { p10 = new P10();}
        
    }

    public static void start(String n)
    {
         if (n != "p1"){
        p1.start();
         }
         
                  if (n != "p2"){
        p2.start();
         }

                  if (n != "p3"){
        p3.start();
         }

                  if (n != "p4"){
        p4.start();
         }

                  if (n != "p5"){
        p5.start();
         }

                  if (n != "p6"){
        p6.start();
         }

                  if (n != "p7"){
        p7.start();
         }

                  if (n != "p8"){
        p8.start();
         }

                  if (n != "p9"){
        p9.start();
         }

                  if (n != "p10"){
        p10.start();
         }

    }

    public static void stop(String n)
    {
       if (n != "p1"){ p1.interrupt();}
       if (n != "p2"){ p2.interrupt();}
       if (n != "p3"){ p3.interrupt();}
       if (n != "p4"){ p4.interrupt();}
       if (n != "p5"){ p5.interrupt();}
       if (n != "p6"){ p6.interrupt();}
       if (n != "p7"){ p7.interrupt();}
       if (n != "p8"){ p8.interrupt();}
       if (n != "p9"){ p9.interrupt();}
       if (n != "p10"){ p10.interrupt();}
    }

    public static int isactive(String n)
    {
       if (n != "p1"){  ret = !p1.isAlive() ? 0 : 1;}
       if (n != "p2"){  ret = !p2.isAlive() ? 0 : 1;}
       if (n != "p3"){  ret = !p3.isAlive() ? 0 : 1;}
       if (n != "p4"){  ret = !p4.isAlive() ? 0 : 1;}
       if (n != "p5"){  ret = !p5.isAlive() ? 0 : 1;}
       if (n != "p6"){  ret = !p6.isAlive() ? 0 : 1;}
       if (n != "p7"){  ret = !p7.isAlive() ? 0 : 1;}
       if (n != "p8"){  ret = !p8.isAlive() ? 0 : 1;}
       if (n != "p9"){  ret = !p9.isAlive() ? 0 : 1;}
       if (n != "p10"){  ret = !p10.isAlive() ? 0 : 1;}
       
       return ret;
    }
}
