import javax.microedition.lcdui.*;

public class Lib_st{
// ***********************************
 public static Graphics g=M.G;
 public static int wpos,pos,xp,x,y,w,h;
// ***********************************
 public static void pt(String s){
// *******
   if(s.length()>0){
    String word;
    int hs=g.getFont().getHeight();
    int ind=0;
    while(ind<s.length()&&y<h){
     s=s.substring(ind);
     ind=s.indexOf(" ");
     ind=(ind==-1)?s.length():ind;
     word=s.substring(0,ind);
     wpos=g.getFont().stringWidth(word+" ");
     if(pos+wpos>w){
      pos=wpos; xp=x; y=y+hs+1;
     } else {
      pos=pos+wpos;
     }
     g.drawString(word+" ",xp,y+hs,g.LEFT|g.BOTTOM);
     xp=x+pos;
     ind++;
    }
   }
// *******
 }
// ***********************************
 public static void fontstyle(String s,int xx,int yy,int ww,int hh){
// *******
   xp=xx;
   x=xx;
   y=yy;
   w=ww;
   h=hh;
   pos=0;
   int gx=g.getClipX();
   int gy=g.getClipY();
   int gw=g.getClipWidth();
   int gh=g.getClipHeight();
   g.setClip(x,y,w,h);
   if(s.length()>9){
    int ind=1,fst,fsz;
    String op=s.substring(0,1);
    while(ind<=s.length()){
     s=s.substring(ind);
     ind=s.indexOf(op);
     ind=(ind==-1)?s.length():ind;
// *******
     switch(s.charAt(0)){
      case 98:
       fst=Font.STYLE_BOLD;
       break;
      case 105:
       fst=Font.STYLE_ITALIC;
       break;
      default:
       fst=Font.STYLE_PLAIN;
     }
// *******
     switch(s.charAt(1)){
      case 115:
       fsz=Font.SIZE_SMALL;
       break;
      case 108:
       fsz=Font.SIZE_LARGE;
       break;
      default:
       fsz=Font.SIZE_MEDIUM;
     }
// *******
     g.setFont(Font.getFont(Font.FACE_SYSTEM,fst,fsz));
     g.setColor(Integer.parseInt(s.substring(2,8),16));
     pt(s.substring(8,ind));
     ind++;
    }
   }
   g.setClip(gx,gy,gw,gh);
// *******
 }
// ***********************************
}
