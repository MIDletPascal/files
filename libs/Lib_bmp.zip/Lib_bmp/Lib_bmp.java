import java.io.*;
import javax.microedition.io.Connector;
import javax.microedition.io.file.FileConnection;
import javax.microedition.lcdui.*;

public class Lib_bmp
{



    public static void savebmp(Image image,String filename)
        throws IOException
    {
        FileConnection fileconnection = (FileConnection)Connector.open("file://" + filename, 3);
        if(fileconnection.exists())
            fileconnection.delete();
        fileconnection.create();
        OutputStream outputstream = fileconnection.openOutputStream();
        outputstream.write(new byte[] {
            66, 77
        });
        int i = ((image.getWidth() * 3 + 3) / 4) * 4;
        int j = i * image.getHeight() + 54;
        outputstream.write(new byte[] {
            (byte)(0xff & j >> 0), (byte)(0xff & j >> 8), (byte)(0xff & j >> 16), (byte)(0xff & j >> 24)
        });
        outputstream.write(new byte[] {
            0, 0, 0, 0
        });
        outputstream.write(new byte[] {
            54, 0, 0, 0
        });
        outputstream.write(new byte[] {
            40, 0, 0, 0
        });
        outputstream.write(new byte[] {
            (byte)(0xff & image.getWidth() >> 0), (byte)(0xff & image.getWidth() >> 8), (byte)(0xff & image.getWidth() >> 16), (byte)(0xff & image.getWidth() >> 24)
        });
        outputstream.write(new byte[] {
            (byte)(0xff & image.getHeight() >> 0), (byte)(0xff & image.getHeight() >> 8), (byte)(0xff & image.getHeight() >> 16), (byte)(0xff & image.getHeight() >> 24)
        });
        outputstream.write(new byte[] {
            1, 0
        });
        outputstream.write(new byte[] {
            24, 0
        });
        outputstream.write(new byte[] {
            0, 0, 0, 0
        });
        j -= 54;
        outputstream.write(new byte[] {
            (byte)(0xff & j >> 0), (byte)(0xff & j >> 8), (byte)(0xff & j >> 16), (byte)(0xff & j >> 24)
        });
        outputstream.write(new byte[] {
            0, 0, 0, 0
        });
        outputstream.write(new byte[] {
            0, 0, 0, 0
        });
        outputstream.write(new byte[] {
            0, 0, 0, 0
        });
        outputstream.write(new byte[] {
            0, 0, 0, 0
        });
        int ai[] = new int[image.getWidth()];
        for(int k = image.getHeight() - 1; k >= 0; k--)
        {
             image.getRGB(ai,0,image.getWidth(),0,k,image.getWidth(),1);
            for(int l = 0; l < ai.length; l++)
                outputstream.write(new byte[] {
                    (byte)(0xff & ai[l]), (byte)(0xff & ai[l] >> 8), (byte)(0xff & ai[l] >> 16)
                });

            outputstream.write(new byte[i - image.getWidth() * 3]);
        }

        outputstream.close();
        fileconnection.close();
    }
}
