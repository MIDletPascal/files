class Thread_class extends Thread{

  public void run(){

   M.threadaction();
  }

  public void interrupt(){
  }

}
