class Lib_thread {


public static  Thread_class thread;

public static void init(){
thread=new Thread_class();
}

public static void start(){
thread.start();
}

public static void stop(){
thread.interrupt();
}

public static int isactive(){
if(thread.isAlive()==true){
  return 1;}else{return 0;}
}


}

